export interface Product {
  id: string
  name: string
  price: number
  image: string
  category: string
  description: string
  status: "active" | "inactive"
  priority: number
  link?: string
}

export interface Category {
  id: string
  name: string
  slug: string
  image: string
}

export interface Order {
  id: string
  productId: string
  productName: string
  customerName: string
  phone: string
  address: string
  price: number
  status: "pending" | "confirmed" | "delivered" | "cancelled"
  createdAt: string
  adminMessage?: string
}

export interface User {
  id: string
  name: string
  phone: string
  address: string
  role: "admin" | "user"
  status: "active" | "inactive"
  createdAt: string
  lastLogin?: string
}
